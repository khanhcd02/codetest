from flask import Flask, jsonify, request, render_template
import subprocess
import re
from controllers.interfacesController import interfaces_blueprint
app = Flask(__name__)
app.register_blueprint(interfaces_blueprint, name='interfaces_blueprint')

if __name__ == '__main__':
    app.run(debug=True)
