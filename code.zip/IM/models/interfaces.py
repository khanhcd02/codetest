import subprocess
import re

class Interface:
    def __init__(self, name, ip_address=None, subnet_mask=None, mac_address=None, status=None):
        self.name = name
        self.ip_address = ip_address
        self.subnet_mask = subnet_mask
        self.mac_address = mac_address
        self.status = status

    def get_interfaces(self):
        result = subprocess.run(['ifconfig'], capture_output=True, text=True)
        interface_names = re.findall(r'(\w+): flags', result.stdout)
        interfaces = [self.get_interface_details(name) for name in interface_names]
        return interfaces

    def get_interface_details(self, interface):
        result = subprocess.run(['ifconfig', interface], capture_output=True, text=True)
        details = result.stdout
        ip_address = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', details)
        subnet_mask = re.search(r'netmask (\d+\.\d+\.\d+\.\d+)', details)
        mac_address = re.search(r'ether ([\da-fA-F:]+)', details)
        status = 'UP' if 'UP' in details else 'DOWN'

        return Interface(
            name=interface,
            ip_address=ip_address.group(1) if ip_address else None,
            subnet_mask=subnet_mask.group(1) if subnet_mask else None,
            mac_address=mac_address.group(1) if mac_address else None,
            status=status
        )
