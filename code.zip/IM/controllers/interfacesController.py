from models.interfaces import Interface
from flask import Blueprint, request, render_template, redirect
import subprocess
import re
interfaces_blueprint = Blueprint('interface', __name__)

@interfaces_blueprint.route('/create', methods=['GET', 'POST'])
def add_interface():
    if request.method == 'POST':
        interface = Interface()
        interface.name = request.form['name']
        

def update_interface(interface_name, new_data):
    # Implement updating an existing network interface
    pass

def delete_interface(interface_name):
    # Implement deleting an existing network interface
    pass

def toggle_interface(interface_name, new_status):
    # Implement toggling the status of a network interface
    pass

def change_network_settings(interface_name, new_settings):
    # Implement changing network settings for a network interface
    pass

@interfaces_blueprint.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        text = request.form['txt']
    return render_template('index.html')

@interfaces_blueprint.route('/interfaces', methods=['GET'])
def list_interfaces():
    interfaces = get_interfaces()
    return jsonify(interfaces)

@interfaces_blueprint.route('/interfaces/<interface>', methods=['GET'])
def interface_details(interface):
    details = get_interface_details(interface)
    return render_template('interface_detail.html', interface=interface, details=details)

@interfaces_blueprint.route('/interfaces/<interface>', methods=['POST'])
def configure_interface(interface):
    ip_address = request.json.get('ip_address')
    subnet_mask = request.json.get('subnet_mask')
    gateway = request.json.get('gateway')

    if ip_address and subnet_mask:
        subprocess.run(['sudo', 'ifconfig', interface, ip_address, 'netmask', subnet_mask])
    if gateway:
        subprocess.run(['sudo', 'route', 'add', 'default', 'gw', gateway, interface])
    
    return jsonify({'status': 'success'})

@interfaces_blueprint.route('/interfaces/<interface>/status', methods=['POST'])
def change_interface_status(interface):
    action = request.json.get('action')
    
    if action == 'up':
        subprocess.run(['sudo', 'ifconfig', interface, 'up'])
    elif action == 'down':
        subprocess.run(['sudo', 'ifconfig', interface, 'down'])
    else:
        return jsonify({'status': 'invalid action'}), 400

    return jsonify({'status': 'success'})