# app/routes.py
from app import app, db
from flask import request, jsonify
from app.models import User

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    if username:
        user = User(username=username)
        db.session.add(user)
        db.session.commit()
        return jsonify({'message': 'User registered successfully'})
    else:
        return jsonify({'error': 'Username is required'}), 400

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    user = User.query.filter_by(username=username).first()
    if user:
        return jsonify({'message': 'Login successful'})
    else:
        return jsonify({'error': 'Invalid username'}), 401
