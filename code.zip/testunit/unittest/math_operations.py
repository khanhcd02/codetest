# math_operations.py

def add(x, y):
    """Thực hiện phép cộng hai số."""
    return x + y
