# test_math_operations.py

import unittest
from math_operations import add

class TestMathOperations(unittest.TestCase):
    def test_add(self):
        # Test tính chính xác của phép cộng
        self.assertEqual(add(1, 2), 3)
        self.assertEqual(add(-1, 1), 0)
        self.assertEqual(add(0, 0), 0)

    def test_add_float(self):
        # Test cho phép cộng các số thực
        self.assertAlmostEqual(add(1.1, 2.2), 3.3)
        self.assertAlmostEqual(add(0.1, 0.2), 0.3)
        
if __name__ == '__main__':
    unittest.main()
