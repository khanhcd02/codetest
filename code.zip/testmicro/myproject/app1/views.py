from django.http import HttpResponse

def index(request):
    return HttpResponse("This is the shop homepage.")

def product_detail(request, product_id):
    return HttpResponse(f"This is the detail page for product {product_id}.")
