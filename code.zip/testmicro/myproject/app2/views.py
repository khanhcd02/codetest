from django.http import HttpResponse

def index(request):
    return HttpResponse("This is the blog homepage.")

def post_detail(request, post_id):
    return HttpResponse(f"This is the detail page for post {post_id}.")
