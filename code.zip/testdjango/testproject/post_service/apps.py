from django.apps import AppConfig


class PostServiceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'post_service'
