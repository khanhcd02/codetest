from django.http import JsonResponse
from .models import Post

def create_post(request):
    # Xử lý logic tạo bài viết
    #tạo lỗi test microservice
    a = 1 / 0
    return JsonResponse({'message': 'Post created successfully'})

def get_posts(request):
    posts = Post.objects.all()
    data = [{'title': post.title, 'content': post.content} for post in posts]
    return JsonResponse(data, safe=False)
