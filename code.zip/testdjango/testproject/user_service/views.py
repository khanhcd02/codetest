from django.http import JsonResponse
from .models import User

def create_user(request):
    # Xử lý logic tạo người dùng
    return JsonResponse({'message': 'User created successfully'})

def get_users(request):
    users = User.objects.all()
    data = [{'username': user.username, 'email': user.email} for user in users]
    return JsonResponse(data, safe=False)
