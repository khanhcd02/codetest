from django.db import models

class Item(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.name

class NetworkInterface(models.Model):
    name = models.CharField(max_length=100)
    ip_address = models.GenericIPAddressField()
    subnet_mask = models.GenericIPAddressField()
    mac_address = models.CharField(max_length=17)
    status = models.CharField(max_length=10)
    gateway = models.GenericIPAddressField(blank=True, null=True)
    dns = models.GenericIPAddressField(blank=True, null=True)

    def __str__(self):
        return self.name