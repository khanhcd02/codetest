# admin.py
from django.contrib import admin
from .models import NetworkInterface

class NetworkInterfaceAdmin(admin.ModelAdmin):
    list_display = ('name', 'ip_address', 'subnet_mask', 'mac_address', 'status', 'gateway', 'dns')
    search_fields = ('name', 'ip_address', 'mac_address')

admin.site.register(NetworkInterface, NetworkInterfaceAdmin)
