from django.shortcuts import render, redirect
from .models import Item

def item_list(request):
    items = Item.objects.all()
    return render(request, 'item/item_list.html', {'items': items})

def add_item(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        Item.objects.create(name=name, description=description)
        return redirect('item_list')
    return render(request, 'item/add_item.html')

def edit_item(request, pk):
    item = Item.objects.get(pk=pk)
    if request.method == 'POST':
        item.name = request.POST.get('name')
        item.description = request.POST.get('description')
        item.save()
        return redirect('item_list')
    return render(request, 'item/edit_item.html', {'item': item})

def delete_item(request, pk):
    item = Item.objects.get(pk=pk)
    item.delete()
    return redirect('item_list')
